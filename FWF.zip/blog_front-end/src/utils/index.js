export const isDef = (v) => v !== null || v !== undefined;
export const isUndef = (v) => v === null || v === undefined;
