export const LS_KEYS = {
  JWT: 'JWT',
};
