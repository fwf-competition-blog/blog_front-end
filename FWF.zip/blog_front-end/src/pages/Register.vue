<script setup></script>
<template>注册页</template>
