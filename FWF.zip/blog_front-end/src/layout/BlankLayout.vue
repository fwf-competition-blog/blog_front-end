<script setup></script>
<template><route-view></route-view></template>
