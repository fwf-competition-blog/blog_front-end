# 状态管理

1. 使用时导入 useStore
2. 使用方法: `const store = useStore(moduleName)`
3. 具体文档参考 https://pinia.vuejs.org/core-concepts/
