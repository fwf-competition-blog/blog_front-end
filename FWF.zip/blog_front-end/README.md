# 运行

1. 使用 vscode 打开项目目录，会提示安装推荐插件，点击后安装
2. npm i 安装依赖
3. npm run dev 运行项目
